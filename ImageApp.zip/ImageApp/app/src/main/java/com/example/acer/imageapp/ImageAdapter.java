package com.example.acer.imageapp;

import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.acer.imageapp.R;

public class ImageAdapter extends RecyclerView.Adapter<ViewHolder> {




    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }


    @Override
    public int getItemCount() {
        return 0;
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
     ImageView imageView;
        ConstraintLayout constraintLayout;


        public ViewHolder(View itemView) {
            super(itemView);
            imageView= itemView.findViewById(R.id.coverimage);
            constraintLayout =(ConstraintLayout)itemView.findViewById(R.id.conlayout);



        }
    }

    }
