package com.example.acer.imageapp;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Intent;
import android.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    EditText edit;
    String data1;
    public static JSONArray hits;
    public static StringBuilder sb;
    String da;


    public static final int CON=251;

    public static final String SEARCHURL="https://pixabay.com/api/?key=10745985-6c1f34ea81c655befc704e6f1&q=cat";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit=findViewById(R.id.edittext);
        Bundle b = new Bundle();



        android.support.v4.app.LoaderManager loaderManager=getSupportLoaderManager();
        android.support.v4.content.Loader<String> loader = loaderManager.getLoader(CON);
        if(loader==null)
            loaderManager.initLoader(CON,null, (android.support.v4.app.LoaderManager.LoaderCallbacks<Object>) this);
        else {
            loaderManager.restartLoader(CON, null, (android.support.v4.app.LoaderManager.LoaderCallbacks<Object>) this);

        }
        Toast.makeText(this, ""+da, Toast.LENGTH_SHORT).show();


    }


    public void submit(View view) {
        if(!TextUtils.isEmpty(edit.getText().toString().trim())){

            /*Intent i=new Intent(MainActivity.this,Detail.class);
            startActivity(i);*/


        }
        else {
            edit.setError("invalid");
        }
    }

    @Override
    public Loader<String> onCreateLoader(int id, final Bundle args) {

        return new AsyncTaskLoader<String>(this) {

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Override
            public String loadInBackground() {
               try{
                   URL url1=new URL(args.getString(SEARCHURL));
                   HttpURLConnection connection=(HttpURLConnection)url1.openConnection();
                   connection.setRequestMethod("GET");
                   connection.connect();
                   InputStream is=connection.getInputStream();
                   StringBuilder builder=new StringBuilder();
                   BufferedReader reader=new BufferedReader(new InputStreamReader(is));
                   String line;
                   while ((line=reader.readLine())!=null){
                       builder.append(line);
                   }
                   return builder.toString();
               } catch (MalformedURLException e) {
                   e.printStackTrace();
               } catch (ProtocolException e) {
                   e.printStackTrace();
               } catch (IOException e) {
                   e.printStackTrace();
               }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<String> loader, String data) {

        data1=data;
        assign(data1);


    }

    private void assign(String data1) {

        try {
            JSONObject jsonObject=new JSONObject(data1);
            hits=jsonObject.getJSONArray("hits");
            for (int i=0;i<hits.length();i++) {
                sb = new StringBuilder();
                JSONObject position = hits.getJSONObject(i);
                JSONObject j= (JSONObject) position.get("largeImageURL");
                Toast.makeText(this, ""+j, Toast.LENGTH_SHORT).show();
                da=j.toString();

            }

            } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }
}
